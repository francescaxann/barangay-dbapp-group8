
import javax.swing.*;

public class ProjectPanel extends JPanel {
    public ProjectPanel() {
        add(new JLabel("ProjectPanel module under construction..."));
    }
}
