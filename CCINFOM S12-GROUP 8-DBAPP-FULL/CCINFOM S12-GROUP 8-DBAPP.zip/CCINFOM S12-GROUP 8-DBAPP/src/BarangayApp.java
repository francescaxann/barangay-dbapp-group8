
import javax.swing.*;
import java.awt.*;

public class BarangayApp extends JFrame {
    public BarangayApp() {
        setTitle("Barangay Records Management System");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Residents", new ResidentsPanel());
        tabs.add("Staff", new StaffPanel());
        tabs.add("Incidents", new IncidentPanel());
        tabs.add("Projects", new ProjectPanel());
        tabs.add("Reports", new ReportsPanel());

        add(tabs);
    }
}
