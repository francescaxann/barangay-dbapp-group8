
import javax.swing.*;

public class IncidentPanel extends JPanel {
    public IncidentPanel() {
        add(new JLabel("IncidentPanel module under construction..."));
    }
}
