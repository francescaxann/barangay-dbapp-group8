
import javax.swing.*;

public class StaffPanel extends JPanel {
    public StaffPanel() {
        add(new JLabel("StaffPanel module under construction..."));
    }
}
