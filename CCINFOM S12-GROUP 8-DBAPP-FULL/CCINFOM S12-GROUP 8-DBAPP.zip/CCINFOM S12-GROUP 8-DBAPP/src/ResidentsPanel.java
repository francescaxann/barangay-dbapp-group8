
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ResidentsPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;

    public ResidentsPanel() {
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[] {
            "ID", "First Name", "Last Name", "Birth Date", "Gender", "Civil Status",
            "Occupation", "Contact", "Street", "Residency Start", "Rating"
        }, 0);
        table = new JTable(model);
        loadResidents();

        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel(new GridLayout(0, 2));
        JTextField[] fields = new JTextField[10];
        String[] labels = {"First Name", "Last Name", "Birth Date (yyyy-mm-dd)", "Gender", "Civil Status",
                "Occupation", "Contact No", "Street", "Residency Start (yyyy-mm-dd)", "Rating"};

        for (int i = 0; i < fields.length; i++) {
            form.add(new JLabel(labels[i]));
            fields[i] = new JTextField();
            form.add(fields[i]);
        }

        JButton addBtn = new JButton("Add Resident");
        addBtn.addActionListener(e -> {
            try (Connection con = DBConnector.getConnection()) {
                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO Residents (firstName, lastName, birthDate, gender, civilStatus, occupation, contactNo, streetName, residencyStart, satisfactionRating) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );
                for (int i = 0; i < fields.length; i++) {
                    ps.setString(i + 1, fields[i].getText());
                }
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Resident added!");
                loadResidents();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        add(form, BorderLayout.SOUTH);
        add(addBtn, BorderLayout.NORTH);
    }

    private void loadResidents() {
        model.setRowCount(0);
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Residents");
            while (rs.next()) {
                model.addRow(new Object[] {
                    rs.getInt("residentID"),
                    rs.getString("firstName"),
                    rs.getString("lastName"),
                    rs.getDate("birthDate"),
                    rs.getString("gender"),
                    rs.getString("civilStatus"),
                    rs.getString("occupation"),
                    rs.getString("contactNo"),
                    rs.getString("streetName"),
                    rs.getDate("residencyStart"),
                    rs.getDouble("satisfactionRating")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
