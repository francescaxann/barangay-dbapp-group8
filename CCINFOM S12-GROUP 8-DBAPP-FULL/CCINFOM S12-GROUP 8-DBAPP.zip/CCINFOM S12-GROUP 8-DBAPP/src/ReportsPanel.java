
import javax.swing.*;

public class ReportsPanel extends JPanel {
    public ReportsPanel() {
        add(new JLabel("ReportsPanel module under construction..."));
    }
}
